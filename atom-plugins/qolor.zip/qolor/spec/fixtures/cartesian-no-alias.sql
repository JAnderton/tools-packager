select * from employee, department
where employee.DepartmentID = department.DepartmentID
