insert into myschema.insert_into (a,b,c)
