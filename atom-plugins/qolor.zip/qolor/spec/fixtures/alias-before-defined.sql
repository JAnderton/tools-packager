select d.foo from defined_later d
