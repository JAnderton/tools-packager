select d.foo from defined_later as d
