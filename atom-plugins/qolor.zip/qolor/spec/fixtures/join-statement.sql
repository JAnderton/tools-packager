left join person p on p.id = f.id JOIN foo f on f.id=p.id
