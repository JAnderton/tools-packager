select * from test t where foo='foo'
