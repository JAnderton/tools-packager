select * into #temp2 tmp2
