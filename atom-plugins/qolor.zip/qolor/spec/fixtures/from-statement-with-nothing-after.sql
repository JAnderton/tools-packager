select * from test t

-- HANDLE NOTHING AFTER (WEIRD, BUT A REAL CASE)
