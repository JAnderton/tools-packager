select * from employee e, department d
where e.DepartmentID = d.DepartmentID
