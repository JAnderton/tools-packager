select field from mySchema.myTable where 1=1
