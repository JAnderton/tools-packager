select
    *
from
    newlines    n
where
    n.foo    =     n.foo
