This is not sql, and if opened / saved should not remove existing decorations in views that have qolored sql.
