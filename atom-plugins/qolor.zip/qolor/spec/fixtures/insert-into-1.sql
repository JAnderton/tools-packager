insert into insert_table values (0,1)
