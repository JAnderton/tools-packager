select * from test2 t2 where t2.foo='foo'
