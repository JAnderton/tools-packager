SeLeCt * FROM test t where t.foo='foo'
