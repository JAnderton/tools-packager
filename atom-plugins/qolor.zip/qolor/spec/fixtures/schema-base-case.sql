select tab.field from mySchema.myTable tab
