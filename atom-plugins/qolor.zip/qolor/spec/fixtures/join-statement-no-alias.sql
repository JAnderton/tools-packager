select * from employee join department on employee.DepartmentID = department.DepartmentID
