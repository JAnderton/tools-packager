select * from #temp1
