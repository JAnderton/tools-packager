delete from mySchema.myTable
    where 2=2
