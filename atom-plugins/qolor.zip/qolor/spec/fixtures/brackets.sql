select * from [test_brackets] b
