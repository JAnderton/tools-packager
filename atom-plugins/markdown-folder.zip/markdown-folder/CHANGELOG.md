## 0.1.0 - First Release
* Folding and unfolding individual headings
* Fold all at different levels
* Unfold all
