To make the maintainer's life easier, I...

- [ ] created at least 1 spec to cover my changes,
- [ ] `npm test`ed my code and it's green like an :green_apple:,
- [ ] adjusted the `readme.md`, if it was necessary and
- [ ] would like to receive get a :beer: or :coffee: after that hard work!
