Thank you very much for contributing! :heart: Leave us any feedback, idea or issue -- we are trying hard to improve atom-editorconfig!


### Involved .editorconfig-files

```
Please replace this by the content of the involved .editorconfig/s
```

### Directory structure

```
Please replace this by the output of `tree -a .` or `tree . \f`
```

### Installed packages

```
Please replace this by the output of `apm list`
```
