# Ansible core

git checkout 7806c50
git merge 4e0c01b

git checkout 3a015a7
git merge 6676720
