# ascii-art package

Convert selected text to ascii art banner

This is the source code for the [create your own package](https://atom.io/docs/latest/hacking-atom-package-modifying-text) tutorial.
