## 0.2.5
* Fix select inside quote w/ cursor just before end quote(@rahatarmanahmed)

## 0.2.4
* Expound on how to customize selected regions(@stevenhauser)
* Fix deprecated calls

## 0.2.3
* Fixed #1

## 0.2.2
* Add expand-region:select-word-include-dash
* Add expand-region:select-word-include-dash-and-dot
* Update default settings

## 0.2.1
* Add source.css settings

## 0.2.0
* Fix autoscroll
* Add expand-region:select-fold
* Update default settings

## 0.1.0 - First Release
* Every feature added
* Every bug fixed
