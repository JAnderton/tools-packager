Markdown Format Package
=======================

Formats your Markdown text (to look like the rendered HTML) on save.

![Markdown Format Demo](https://github.com/shurcooL/atom-markdown-format/blob/master/Demo.gif?raw=true)
