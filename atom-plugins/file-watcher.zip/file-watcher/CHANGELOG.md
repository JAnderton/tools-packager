## 0.4.0 - Add Prompt on Change
* Allow users to also show the prompt when the file changes, even if there are no unsaved changes in Atom

## 0.3.1 - Add Compare Grammar support
* Add grammar settings to the new buffer
  * credit to [@kankaristo](https://github.com/lwblackledge/file-watcher/issues/1#issuecomment-109119005) for change

## 0.3.0 - Add Compare
* Allows users to compare the disk and memory version of the file

## 0.1.0 - Confirm implementation
* Prompts for every file that has a conflict

## 0.0.2 - Initial single-file implementation
* Shows a single prompt when one file changes

## 0.0.1 - Alpha
* Added console logs when files change
