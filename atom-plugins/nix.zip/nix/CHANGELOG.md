## 2.1.0 - Comma fight

- Converted from sublime-nix
- Fixed comma-first function parameter definition but that was not a problem on Atom

## 2.0.0 - Grammar School

- Converted from sublime-nix
- Much more complete implementation of the Nix grammar

## 0.9.0 - First Release
* Converted from sublime-nix
