'use babel';

import YamlSortkeyView from '../lib/yaml-sortkey-view';

describe('YamlSortkeyView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
