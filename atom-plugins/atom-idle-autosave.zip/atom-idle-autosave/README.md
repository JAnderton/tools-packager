# atom-idle-autosave package

Saves editor on idle
