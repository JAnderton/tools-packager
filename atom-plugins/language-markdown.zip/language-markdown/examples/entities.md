This sentence contains a singular & which shouldn't be marked by `language-html` as erronous, because it's more or less valid from an end-user's perspective.

&
