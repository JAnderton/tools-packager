
Given some function $f \in \{0,1\}^*\to\{0,1\}^*$, there must exist ...

$$
f \in \{0,1\}^*\to\{0,1\}^*
$$

```latex
f \in \{0,1\}^*\to\{0,1\}^*
```

```mathematica
Log[10,Abs[x]]+Accuracy[x]
```

the reference image $I_r$ and the template image $I_t$.

$$
d_y(x) = D \del{f_r(x), f_t(y)}
$$ {#eq:dist}

# Heading

$$
d_y(x) = D \del{f_r(x), f_t(y)}
$$ |

Some regular text...
