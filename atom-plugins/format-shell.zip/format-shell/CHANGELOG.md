# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.0.1"></a>
## [1.0.1](https://github.com/focusaurus/atom-format-shell/compare/v1.0.0...v1.0.1) (2016-10-10)



<a name="1.0.0"></a>
# 1.0.0 (2016-10-10)


### Features

* Format shell script code within atom ([aad24f9](https://github.com/focusaurus/atom-format-shell/commit/aad24f9))
