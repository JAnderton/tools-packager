# Atom Format Shell

Automatically format/beautify/pretty-print your shell script source code from within the Atom text editor.

The formatting is powered under the hood by [shfmt](https://github.com/mvdan/sh), which must be installed separately from atom and this atom package.

You can install shfmt by [downloading a release for your OS here](https://github.com/mvdan/sh/releases).
