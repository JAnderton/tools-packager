When editing long/wide YAML files, you can use this to see the YAML namespace that you are currently in.
It only works when the grammar is YAML and refreshes every 100ms.

Activate with CTRL+ALT+Y

Disclaimer: I had no idea what I was doing when I was writing this, it's the first time I ever saw CoffeeScript/JavaScript. So any bugs/features might get ignored. Shameless rip of the status-bar-clock package.

TODO: subscribe to event, such as grammar change or cursor move.
