# Code Block

```javascript
if a === 3 {
  b = 5
}
```

encoding → issue
